# Log in for CLI use to austrakka (any instance). 

# This script must be sourced, not run, i.e.
#   source austrakka-login.sh

export AT_TOKEN=$(austrakka auth user)