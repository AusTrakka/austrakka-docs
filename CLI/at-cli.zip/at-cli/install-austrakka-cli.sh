# Creates a conda environment called austrakka
# Installs the austrakka CLI, and set environment variables in that environment
# To use the CLI once installed, you will need to
#    conda activate austrakka
#    source austrakka-login.sh
#    austrakka -h

ENV_NAME="austrakka"
AT_ENV_VAR="prod"
PACKAGE="austrakka"
URI="https://apimgwdev.austrakka.net.au/prod/v1"

# abort if any step fails
set -e

eval "$(conda shell.bash hook)"

conda create -y -n $ENV_NAME python=3.9
conda activate $ENV_NAME

pip install $PACKAGE
conda env config vars set AT_ENV=$AT_ENV_VAR
conda env config vars set AT_URI=$URI

# Create at-login alias when environment is activated
echo "alias at-login=\"export AT_TOKEN=\\\$(austrakka auth user)\"" > ${CONDA_PREFIX}/etc/conda/activate.d/austrakka-alias.sh

# Return to base environment
conda activate

echo
echo "To use the CLI, activate the conda environment and log in:"
echo "    conda activate austrakka"
echo "    at-login"
echo "    austrakka -h"