# Updates the austrakka CLI, within the austraka conda environment 

ENV_NAME="austrakka"
PACKAGE="austrakka"

# abort if any step fails
set -e

eval "$(conda shell.bash hook)"

conda activate $ENV_NAME

pip install --upgrade --index-url 'https://pkgs.dev.azure.com/mduphl/austrakka/_packaging/austrakka-feed/pypi/simple/' $PACKAGE

echo
echo "To use the CLI, activate the conda environment and log in:"
echo "    conda activate austrakka"
echo "    source austrakka-login.sh"
echo "    austrakka -h"
